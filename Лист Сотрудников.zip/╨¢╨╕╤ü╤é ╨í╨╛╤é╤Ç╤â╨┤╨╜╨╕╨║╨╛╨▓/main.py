from tkinter import *
from tkinter import ttk

class AddEmployessWindow:
    def __init__(self, add_employees_window):
        """титульник и размеры окна"""
        add_employees_window.title("Adding people")
        add_employees_window.geometry("250x200")


        """виджеты"""
        self.full_name = Label(add_employees_window, text="Enter full Name").pack()
        self.input_full_name = Entry(add_employees_window)
        self.input_full_name_packed = self.input_full_name.pack()

        """лэйбл + окно без pack + окно с pack"""
        self.phone = Label(add_employees_window, text="Enter phone number").pack()
        self.input_phone = Entry(add_employees_window)
        self.input_phone_packed = self.input_phone.pack()

        """лэйбл + окно без pack + окно с pack"""
        self.email = Label(add_employees_window, text="Enter email").pack()
        self.input_email = Entry(add_employees_window)
        self.input_email_packed =self.input_email.pack()


        """лэйбл + окно без pack + окно с pack"""
        self.salary = Label(add_employees_window, text="Enter salary").pack()
        self.input_salary = Entry(add_employees_window)
        self.input_salary_packed = self.input_salary.pack()

        """кнопка создания сотрудника в сиситеме"""
        self.create_button = Button(add_employees_window, text="Create", command= self.send_to_data).pack()
        """удаление окна"""
        self.close_button = Button(add_employees_window,text="Close", command=lambda: add_employees_window.destroy()).pack()




    def send_to_data(self):
        with open("data.txt", "a") as data:
            """запись"""
            data.write("\n" + str(self.input_full_name.get()) + "|")
            """чистка строки"""
            self.input_full_name.delete(0, END)

            data.write(str(self.input_phone.get()) + "|")
            self.input_phone.delete(0, END)

            data.write(str(self.input_email.get()) + "|")
            self.input_email.delete(0, END)

            data.write(str(self.input_salary.get()))
            self.input_salary.delete(0, END)
            # table.insert("", END, values=(self.input_full_name.get(), self.input_phone.get(),self.input_email.get(),self.input_salary.get() ))

people = []
"""функция вызова окна добавления сотрудника"""
def add_employees_window():
    window = AddEmployessWindow(Tk())

"""функция демонстрации БД, есть баг с таблицей, а так БД работает"""
def show():

    """БД находится в файле data.txt, так как нет большой разницы использовать sql или txt файл"""
    with open("data.txt", "r") as data:
        info = data.readline()
        while info:
            info = data.readline()
            people.append(tuple(info.split("|")))
        print(people)

    """костыль из за которого баг, решение еще не придумал"""
    for person in people:
        table.insert("", END, values=person)




root = Tk()
root.title("Company Employees List")
root.geometry("250x250")


"""поиск сотрудников - несделано"""
a = ttk.Entry().pack()
"""кнопка добавления сотрудника - сделана"""
add_employees_button = ttk.Button(text="Add", command= add_employees_window).pack()

"""кнопка удаления сотрудника"""
remove_employees_button = ttk.Button(text="Remove").pack()
"""кнопка показа таблицы-перезагрузка - сделана, но есть баг"""
show_button = ttk.Button(text="Show List",command=show).pack()

"""генерация таблички"""
table = ttk.Treeview(columns= ("Full Name", "Phone Number", "Email", "Salary"), show="headings")
table.pack(fill=BOTH, expand=1)
table.heading("Full Name", text="Full Name")
table.heading("Phone Number", text="Phone Number")
table.heading("Email", text="Email")
table.heading("Salary", text="Salary")

root.mainloop()
